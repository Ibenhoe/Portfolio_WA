# Portfolio_WA


Formulier:
Geinspireerd door: https://freefrontend.com/css-forms/
Basic info cursus Web Essentials 1 hfst 4
Grootste problemen ervoor zorgen dat de div in het midden staat, de extra shadow en border-radius werd door copilot in gevuld met een paar kleine correctie naar mijn wensen.


Lettertype Ubuntu: https://fonts.google.com/specimen/Ubuntu 

Submit button:
Door het fout beginnen heb ik moeten opzoeken hoe ik op een input een functie moest toevoegen. https://chat.openai.com/share/4f5dcd90-ed94-42ec-9edb-10c1971a0255 
Hiervan heb ik de onclick gebruikt waardoor ik in javascript kon laten controleren als alles wel was ingevuld. De controle voor de email komt van de website https://www.w3resource.com/javascript/form/email-validation.php.

Extra bij Formulier:
Wanneer men een kleur ingeeft die in de lijst staat zal de tekst veranderen naar de kleur. Voornamelijk copilot heeft de fouten eruit gehaald verder javascript ben ik zelf op gekomen. (opzoek naar de oplossing voor wanneer met het terug weg doet het terug zwart wordt maar heb daar verder nog geen tijd in gestoken)

Navigatie:
Basic info cursus Web Essentials 1 hfst 3

Foto help: https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.iconfinder.com%2Ficons%2F216643%2Fhelp_icon&psig=AOvVaw1pFp5ERiUw5Ztc4hnhCox0&ust=1709310354000000&source=images&cd=vfe&opi=89978449&ved=0CBIQjRxqFwoTCKjf3bb70IQDFQAAAAAdAAAAABAE


Foto inbox: https://www.google.com/url?sa=i&url=https%3A%2F%2Fen.m.wikipedia.org%2Fwiki%2FFile%3AInbox_font_awesome.svg&psig=AOvVaw3N7ejpBkPEisXVzE4HA4jc&ust=1709309822825000&source=images&cd=vfe&opi=89978449&ved=0CBIQjRxqFwoTCNCbzfeI0YQDFQAAAAAdAAAAABAE

Foto profiel: https://www.google.com/url?sa=i&url=https%3A%2F%2Fthenounproject.com%2Fbrowse%2Ficons%2Fterm%2Fprofile%2F&psig=AOvVaw0s4GzcaScMtVXvrY8gU_W_&ust=1709309716097000&source=images&cd=vfe&opi=89978449&ved=0CBIQjRxqFwoTCLiarIOJ0YQDFQAAAAAdAAAAABAE 

Foto home: https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.svgrepo.com%2Fsvg%2F56717%2Fhome&psig=AOvVaw1G9996AXdp_kR3x9vJaqbx&ust=1709309061214000&source=images&cd=vfe&opi=89978449&ved=0CBIQjRxqFwoTCKCtt4yJ0YQDFQAAAAAdAAAAABAE 

Ik heb ervoor gekozen om deze navigatie links te vestigen met de help button helemaal zoals je op veel websites ziet.



Hfst 1: Constante
Ik heb voor de constante gekozen om mijn naam daar in te zetten. Dit zodat ik deze kan laten tonen in de footer door gebruikt te maken van document.getElementById en de innerHTML. Het probleem was wel dat dit alleen werkte op de start pagina hiervoor heb ik het in de LocalStorage gestoken zodat deze wel blijft werken als je van pagina veranderd (bron: https://www.w3schools.com/jsref/prop_win_localstorage.asp).

Api call:
Volledig gemaakt door Chatgpt 
https://chatgpt.com/share/f4dd3c9f-0763-4ecb-8a22-b03b429f0630
Dit komt omdat de vorige api call werkte wel en was ook beter maar kon ik niet in de html krijgen.